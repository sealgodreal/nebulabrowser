@echo off
echo Installing Dependencies...
echo.
python -m pip install mss
python -m pip install pyautogui
python -m pip install Pillow
python -m pip install websocket-client
cls
python create_remote.py
pause