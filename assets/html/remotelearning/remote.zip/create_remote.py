import io
import json
import threading
import time
import urllib.parse
import urllib.request
import urllib.error

import mss
import pyautogui
from PIL import Image

try:
    import websocket
except ImportError:
    print("Missing dependency: websocket-client")
    print("Install it with:")
    print("python -m pip install websocket-client")
    raise SystemExit(1)


SERVER = "https://nebula-remote-streaming-backend.onrender.com"

FPS = 15
JPEG_QUALITY = 60

token = ""
socket = None

running = True
streaming = False

stream_lock = threading.Lock()
monitor_lock = threading.Lock()

selected_monitor = 1


KEYS = {
    " ": "space",
    "Enter": "enter",
    "Escape": "esc",
    "Backspace": "backspace",
    "Tab": "tab",
    "ArrowUp": "up",
    "ArrowDown": "down",
    "ArrowLeft": "left",
    "ArrowRight": "right",
    "Delete": "delete",
    "Home": "home",
    "End": "end",
    "PageUp": "pageup",
    "PageDown": "pagedown",
    "Shift": "shift",
    "Control": "ctrl",
    "Alt": "alt",
    "Meta": "win",
    "CapsLock": "capslock",
    "Insert": "insert",
    "PrintScreen": "printscreen",
}

for i in range(1, 13):
    KEYS[f"F{i}"] = f"f{i}"


def encoded_token():
    return urllib.parse.quote(token, safe="")


def get_token():
    global token

    while not token:
        token = input(" Enter a Connection Token : ").strip()

        if not token:
            print(" - Token cannot be empty.")


def create_connection():
    url = (
        f"{SERVER}/create/?="
        f"{encoded_token()}"
    )

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent":
                "NebulaRemoteAgent/1.0"
        }
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=15
        ) as response:
            data = json.loads(
                response
                .read()
                .decode("utf-8")
            )

    except urllib.error.HTTPError as error:
        try:
            detail = (
                error
                .read()
                .decode("utf-8")
            )
        except Exception:
            detail = str(error)

        print(" - Server error:", detail)
        raise SystemExit(1)

    except Exception as error:
        print(
            " - Could not reach the server:",
            error
        )

        raise SystemExit(1)

    if not data.get("ok"):
        print(
            " - " + data.get(
                "error",
                "Could not create connection."
            )
        )

        raise SystemExit(1)


def get_monitors():
    with mss.MSS() as sct:
        return [
            {
                "id": i,
                "left": monitor["left"],
                "top": monitor["top"],
                "width": monitor["width"],
                "height": monitor["height"],
            }
            for i, monitor in enumerate(
                sct.monitors[1:],
                start=1
            )
        ]


def send_json(message):
    try:
        if (
            socket and
            socket.connected
        ):
            socket.send(
                json.dumps(message)
            )
    except Exception:
        pass


def set_streaming(value):
    global streaming

    with stream_lock:
        streaming = value


def is_streaming():
    with stream_lock:
        return streaming


def send_current_monitor():
    global selected_monitor

    monitors = get_monitors()

    with monitor_lock:
        current = selected_monitor

    if not monitors:
        return

    if current < 1 or current > len(monitors):
        current = 1

        with monitor_lock:
            selected_monitor = 1

    monitor = monitors[current - 1]

    send_json({
        "type": "selected_monitor",
        "monitor": current,
        "width": monitor["width"],
        "height": monitor["height"]
    })


def perform_input(message):
    global selected_monitor

    message_type = message.get(
        "type",
        ""
    )

    if message_type == "select_monitor":

        try:
            requested = int(
                message.get(
                    "monitor",
                    1
                )
            )
        except Exception:
            requested = 1

        monitors = get_monitors()

        if (
            1 <= requested <=
            len(monitors)
        ):
            with monitor_lock:
                selected_monitor = requested

            send_current_monitor()

        return

    if message_type in (
        "mouse_move",
        "mouse_down",
        "mouse_up",
        "mouse_click"
    ):

        try:
            x = int(
                message.get(
                    "x",
                    0
                )
            )

            y = int(
                message.get(
                    "y",
                    0
                )
            )

        except Exception:
            return

        monitors = get_monitors()

        with monitor_lock:
            monitor_id = selected_monitor

        if not (
            1 <= monitor_id <=
            len(monitors)
        ):
            monitor_id = 1

        monitor = monitors[
            monitor_id - 1
        ]

        x = max(
            0,
            min(
                monitor["width"] - 1,
                x
            )
        )

        y = max(
            0,
            min(
                monitor["height"] - 1,
                y
            )
        )

        global_x = (
            monitor["left"] + x
        )

        global_y = (
            monitor["top"] + y
        )

        button = message.get(
            "button",
            "left"
        )

        try:
            pyautogui.moveTo(
                global_x,
                global_y,
                duration=0
            )

            if (
                message_type ==
                "mouse_down"
            ):
                pyautogui.mouseDown(
                    button=button
                )

            elif (
                message_type ==
                "mouse_up"
            ):
                pyautogui.mouseUp(
                    button=button
                )

            elif (
                message_type ==
                "mouse_click"
            ):
                pyautogui.click(
                    button=button
                )

        except Exception:
            pass

        return

    if message_type == "scroll":

        try:
            pyautogui.scroll(
                int(
                    message.get(
                        "amount",
                        0
                    )
                )
            )
        except Exception:
            pass

        return

    if message_type == "text":

        text = message.get(
            "text",
            ""
        )

        if not isinstance(text, str):
            return

        try:
            for character in text:
                if character.isprintable():
                    pyautogui.write(
                        character
                    )
                elif character == "\n":
                    pyautogui.press("enter")
                elif character == "\t":
                    pyautogui.press("tab")

        except Exception:
            pass

        return

    if message_type in (
        "key_down",
        "key_up"
    ):

        key = message.get(
            "key",
            ""
        )

        key = KEYS.get(
            key,
            key.lower()
            if key
            else key
        )

        if not key:
            return

        try:
            if (
                message_type ==
                "key_down"
            ):
                pyautogui.keyDown(
                    key
                )
            else:
                pyautogui.keyUp(
                    key
                )

        except Exception:
            pass


def receive_loop():
    global running

    while running:

        try:
            message = socket.recv()

            if not message:
                running = False
                break

            if isinstance(
                message,
                bytes
            ):
                continue

            data = json.loads(
                message
            )

            message_type = data.get(
                "type",
                ""
            )

            if (
                message_type ==
                "viewer_count"
            ):

                count = int(
                    data.get(
                        "count",
                        0
                    )
                )

                was_streaming = is_streaming()
                now_streaming = count > 0

                set_streaming(
                    now_streaming
                )

                if now_streaming and not was_streaming:
                    print(" - User Connected.")
                elif was_streaming and not now_streaming:
                    print(" - User Disconnected.")

                continue

            if (
                message_type ==
                "send_monitors"
            ):

                send_json({
                    "type":
                        "monitors",
                    "monitors":
                        get_monitors()
                })

                send_current_monitor()

                continue

            perform_input(
                data
            )

        except (
            websocket.WebSocketTimeoutException
        ):
            continue

        except Exception:

            running = False
            break


def stream_loop():
    global running

    frame_interval = (
        1.0 / FPS
    )

    with mss.MSS() as sct:

        while running:

            if not is_streaming():
                time.sleep(0.1)
                continue

            started = time.time()

            try:

                with monitor_lock:
                    monitor_id = (
                        selected_monitor
                    )

                if (
                    monitor_id < 1 or
                    monitor_id >=
                    len(sct.monitors)
                ):
                    monitor_id = 1

                monitor = (
                    sct.monitors[
                        monitor_id
                    ]
                )

                screenshot = sct.grab(
                    monitor
                )

                image = Image.frombytes(
                    "RGB",
                    screenshot.size,
                    screenshot.rgb
                )

                buffer = io.BytesIO()

                image.save(
                    buffer,
                    format="JPEG",
                    quality=JPEG_QUALITY,
                    optimize=True
                )

                if (
                    socket and
                    socket.connected and
                    is_streaming()
                ):

                    socket.send(
                        buffer.getvalue(),
                        opcode=
                            websocket
                            .ABNF
                            .OPCODE_BINARY
                    )

                    send_json({
                        "type":
                            "size",
                        "width":
                            screenshot.width,
                        "height":
                            screenshot.height
                    })

            except Exception:
                pass

            elapsed = (
                time.time() -
                started
            )

            delay = (
                frame_interval -
                elapsed
            )

            if delay > 0:
                time.sleep(
                    delay
                )


def main():
    global socket

    print("Nebula Connect")
    print()
    print()

    get_token()

    print()
    print(" - Connecting to the server...")

    create_connection()

    websocket_url = (
        SERVER
        .replace("https://", "wss://")
        .replace("http://", "ws://")
        + "/connection/?="
        f"{encoded_token()}"
        "&role=agent"
    )

    try:

        socket = (
            websocket.create_connection(
                websocket_url,
                timeout=None,
                http_proxy_host=None,
                http_proxy_port=None
            )
        )

        socket.settimeout(None)

    except Exception as error:

        print(
            " - Could not connect:",
            error
        )

        raise SystemExit(1)

    print(" - Successful! Waiting for user connection...")

    receiver = threading.Thread(
        target=receive_loop,
        daemon=True
    )

    receiver.start()

    try:
        stream_loop()

    except KeyboardInterrupt:
        pass

    finally:

        running = False

        try:
            socket.close()
        except Exception:
            pass

        print()
        print(" - Stopped.")


if __name__ == "__main__":
    main()