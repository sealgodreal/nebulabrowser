import io
import json
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
import ctypes
from ctypes import wintypes
import socket as socket_module

if hasattr(ctypes, "windll"):
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

import mss
from PIL import Image

import websocket

SERVER = "https://nebula-remote-streaming-backend.onrender.com"

FPS = 20
JPEG_QUALITY = 40
MAX_WIDTH = 1280

token = ""
socket = None

running = True
streaming = False

stream_lock = threading.Lock()
monitor_lock = threading.Lock()
socket_lock = threading.Lock()

selected_monitor = 1

stream_size_lock = threading.Lock()
stream_width = None
stream_height = None

last_sent_size = None

KEYS = {
    " ": "space",
    "Enter": "enter",
    "Escape": "esc",
    "Backspace": "backspace",
    "Tab": "tab",
    "ArrowUp": "up",
    "ArrowDown": "down",
    "ArrowLeft": "left",
    "ArrowRight": "right",
    "Delete": "delete",
    "Home": "home",
    "End": "end",
    "PageUp": "pageup",
    "PageDown": "pagedown",
    "Shift": "shift",
    "Control": "ctrl",
    "Alt": "alt",
    "Meta": "win",
    "CapsLock": "capslock",
    "Insert": "insert",
    "PrintScreen": "printscreen",
}

for i in range(1, 13):
    KEYS[f"F{i}"] = f"f{i}"

user32 = ctypes.WinDLL(
    "user32",
    use_last_error=True
)

INPUT_MOUSE = 0
INPUT_KEYBOARD = 1

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_VIRTUALDESK = 0x4000

KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004

WHEEL_DELTA = 120


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [
        ("uMsg", wintypes.DWORD),
        ("wParamL", wintypes.WORD),
        ("wParamH", wintypes.WORD),
    ]


class INPUT_UNION(ctypes.Union):
    _fields_ = [
        ("mi", MOUSEINPUT),
        ("ki", KEYBDINPUT),
        ("hi", HARDWAREINPUT),
    ]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [
        ("type", wintypes.DWORD),
        ("u", INPUT_UNION),
    ]


user32.SendInput.argtypes = (
    wintypes.UINT,
    ctypes.POINTER(INPUT),
    ctypes.c_int,
)

user32.SendInput.restype = wintypes.UINT

user32.SetPhysicalCursorPos.argtypes = (
    wintypes.LONG,
    wintypes.LONG,
)

user32.SetPhysicalCursorPos.restype = wintypes.BOOL

VK = {
    "backspace": 0x08,
    "tab": 0x09,
    "enter": 0x0D,
    "shift": 0x10,
    "ctrl": 0x11,
    "alt": 0x12,
    "pause": 0x13,
    "capslock": 0x14,
    "esc": 0x1B,
    "space": 0x20,
    "pageup": 0x21,
    "pagedown": 0x22,
    "end": 0x23,
    "home": 0x24,
    "left": 0x25,
    "up": 0x26,
    "right": 0x27,
    "down": 0x28,
    "insert": 0x2D,
    "delete": 0x2E,
    "printscreen": 0x2C,
    "win": 0x5B,
    "f1": 0x70,
    "f2": 0x71,
    "f3": 0x72,
    "f4": 0x73,
    "f5": 0x74,
    "f6": 0x75,
    "f7": 0x76,
    "f8": 0x77,
    "f9": 0x78,
    "f10": 0x79,
    "f11": 0x7A,
    "f12": 0x7B,
}

for i in range(ord("a"), ord("z") + 1):
    VK[chr(i)] = i - ord("a") + 0x41

for i in range(ord("0"), ord("9") + 1):
    VK[chr(i)] = i - ord("0") + 0x30

VK.update({
    "num0": 0x60,
    "num1": 0x61,
    "num2": 0x62,
    "num3": 0x63,
    "num4": 0x64,
    "num5": 0x65,
    "num6": 0x66,
    "num7": 0x67,
    "num8": 0x68,
    "num9": 0x69,
    "multiply": 0x6A,
    "add": 0x6B,
    "subtract": 0x6D,
    "decimal": 0x6E,
    "divide": 0x6F,
})


def _is_extended_key(vk):
    return vk in {
        0x21,
        0x22,
        0x23,
        0x24,
        0x25,
        0x26,
        0x27,
        0x28,
        0x2D,
        0x2E,
        0x2C,
        0x5B,
        0x5C,
    }


def win32_move_mouse(x, y):
    try:
        x = int(round(x))
        y = int(round(y))
    except (TypeError, ValueError):
        return False

    return bool(
        user32.SetPhysicalCursorPos(
            wintypes.LONG(x),
            wintypes.LONG(y)
        )
    )


def win32_mouse_button(button, down):
    flags = {
        "left": (
            MOUSEEVENTF_LEFTDOWN,
            MOUSEEVENTF_LEFTUP,
        ),
        "right": (
            MOUSEEVENTF_RIGHTDOWN,
            MOUSEEVENTF_RIGHTUP,
        ),
        "middle": (
            MOUSEEVENTF_MIDDLEDOWN,
            MOUSEEVENTF_MIDDLEUP,
        ),
    }

    button = str(button).lower()

    if button not in flags:
        return

    down_flag, up_flag = flags[button]

    inp = INPUT(
        type=INPUT_MOUSE,
        mi=MOUSEINPUT(
            dx=0,
            dy=0,
            mouseData=0,
            dwFlags=down_flag if down else up_flag,
            time=0,
            dwExtraInfo=None,
        ),
    )

    user32.SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(INPUT)
    )


def win32_click(button="left"):
    win32_mouse_button(button, True)
    win32_mouse_button(button, False)


def win32_scroll(amount):
    try:
        amount = int(amount)
    except Exception:
        return

    if amount == 0:
        return

    inp = INPUT(
        type=INPUT_MOUSE,
        mi=MOUSEINPUT(
            dx=0,
            dy=0,
            mouseData=amount * WHEEL_DELTA,
            dwFlags=MOUSEEVENTF_WHEEL,
            time=0,
            dwExtraInfo=None,
        ),
    )

    user32.SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(INPUT)
    )


def win32_key_down(key):
    if not key:
        return

    key = str(key).lower()
    vk = VK.get(key)

    if vk is None:
        return

    scan_code = user32.MapVirtualKeyW(vk, 0)
    flags = 0

    if _is_extended_key(vk):
        flags |= KEYEVENTF_EXTENDEDKEY

    inp = INPUT(
        type=INPUT_KEYBOARD,
        ki=KEYBDINPUT(
            wVk=vk,
            wScan=scan_code,
            dwFlags=flags,
            time=0,
            dwExtraInfo=None,
        ),
    )

    user32.SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(INPUT)
    )


def win32_key_up(key):
    if not key:
        return

    key = str(key).lower()
    vk = VK.get(key)

    if vk is None:
        return

    scan_code = user32.MapVirtualKeyW(vk, 0)
    flags = KEYEVENTF_KEYUP

    if _is_extended_key(vk):
        flags |= KEYEVENTF_EXTENDEDKEY

    inp = INPUT(
        type=INPUT_KEYBOARD,
        ki=KEYBDINPUT(
            wVk=vk,
            wScan=scan_code,
            dwFlags=flags,
            time=0,
            dwExtraInfo=None,
        ),
    )

    user32.SendInput(
        1,
        ctypes.byref(inp),
        ctypes.sizeof(INPUT)
    )


def win32_unicode_char(character):
    if not character:
        return

    codepoint = ord(character)

    key_down = INPUT(
        type=INPUT_KEYBOARD,
        ki=KEYBDINPUT(
            wVk=0,
            wScan=codepoint,
            dwFlags=KEYEVENTF_UNICODE,
            time=0,
            dwExtraInfo=None,
        ),
    )

    key_up = INPUT(
        type=INPUT_KEYBOARD,
        ki=KEYBDINPUT(
            wVk=0,
            wScan=codepoint,
            dwFlags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
            time=0,
            dwExtraInfo=None,
        ),
    )

    inputs = (INPUT * 2)(
        key_down,
        key_up
    )

    user32.SendInput(
        2,
        inputs,
        ctypes.sizeof(INPUT)
    )


def win32_type_text(text):
    if not isinstance(text, str):
        return

    for character in text:
        if character == "\n":
            win32_key_down("enter")
            win32_key_up("enter")
        elif character == "\t":
            win32_key_down("tab")
            win32_key_up("tab")
        elif character == "\r":
            continue
        elif character.isprintable():
            win32_unicode_char(character)


def encoded_token():
    return urllib.parse.quote(
        token,
        safe=""
    )


def get_token():
    global token

    while not token:
        token = input(
            " Enter a Connection Token : "
        ).strip()

        if not token:
            print(
                " - Token cannot be empty."
            )


def create_connection():
    global token

    url = (
        f"{SERVER}/create/?="
        f"{encoded_token()}"
    )

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent":
                "NebulaRemoteAgent/1.0"
        }
    )

    try:
        with urllib.request.urlopen(
            request,
            timeout=15
        ) as response:
            data = json.loads(
                response.read().decode("utf-8")
            )

    except urllib.error.HTTPError as error:
        try:
            detail = error.read().decode("utf-8")
        except Exception:
            detail = str(error)

        print(
            " - Server error:",
            detail
        )

        raise SystemExit(1)

    except Exception as error:
        print(
            " - Could not reach the server:",
            error
        )

        raise SystemExit(1)

    if not data.get("ok"):
        print(
            " - " + data.get(
                "error",
                "Could not create connection."
            )
        )

        raise SystemExit(1)


def get_monitors():
    with mss.MSS() as sct:
        return [
            {
                "id": i,
                "left": monitor["left"],
                "top": monitor["top"],
                "width": monitor["width"],
                "height": monitor["height"],
            }
            for i, monitor in enumerate(
                sct.monitors[1:],
                start=1
            )
        ]


def get_selected_monitor():
    global selected_monitor

    monitors = get_monitors()

    with monitor_lock:
        monitor_id = selected_monitor

    if not monitors:
        return None

    if (
        monitor_id < 1 or
        monitor_id > len(monitors)
    ):
        monitor_id = 1

        with monitor_lock:
            selected_monitor = 1

    return monitors[monitor_id - 1]


def set_stream_size(width, height):
    global stream_width
    global stream_height

    with stream_size_lock:
        stream_width = int(width)
        stream_height = int(height)


def get_stream_size():
    with stream_size_lock:
        return stream_width, stream_height


def set_streaming(value):
    global streaming

    with stream_lock:
        streaming = value


def is_streaming():
    with stream_lock:
        return streaming


def send_json(message):
    try:
        if socket and socket.connected:
            with socket_lock:
                socket.send(json.dumps(message))
    except Exception:
        pass


def send_current_monitor():
    global selected_monitor

    monitors = get_monitors()

    with monitor_lock:
        current = selected_monitor

    if not monitors:
        return

    if (
        current < 1 or
        current > len(monitors)
    ):
        current = 1

        with monitor_lock:
            selected_monitor = 1

    monitor = monitors[current - 1]

    send_json({
        "type": "selected_monitor",
        "monitor": current,
        "width": monitor["width"],
        "height": monitor["height"]
    })


def perform_input(message):
    global selected_monitor

    message_type = message.get("type", "")

    if message_type == "select_monitor":
        try:
            requested = int(
                message.get(
                    "monitor",
                    1
                )
            )
        except Exception:
            requested = 1

        monitors = get_monitors()

        if 1 <= requested <= len(monitors):
            with monitor_lock:
                selected_monitor = requested

            set_stream_size(0, 0)
            send_current_monitor()

        return

    if message_type in (
        "mouse_move",
        "mouse_down",
        "mouse_up",
        "mouse_click"
    ):
        try:
            x = float(
                message.get(
                    "x",
                    0
                )
            )

            y = float(
                message.get(
                    "y",
                    0
                )
            )
        except Exception:
            return

        monitors = get_monitors()

        with monitor_lock:
            monitor_id = selected_monitor

        if not (
            1 <= monitor_id <= len(monitors)
        ):
            monitor_id = 1

        monitor = monitors[monitor_id - 1]

        monitor_width = monitor["width"]
        monitor_height = monitor["height"]

        stream_w, stream_h = get_stream_size()

        if (
            stream_w and
            stream_h and
            stream_w > 0 and
            stream_h > 0
        ):
            scale_x = (
                monitor_width /
                float(stream_w)
            )

            scale_y = (
                monitor_height /
                float(stream_h)
            )

            x *= scale_x
            y *= scale_y

        x = max(
            0,
            min(
                monitor_width - 1,
                round(x)
            )
        )

        y = max(
            0,
            min(
                monitor_height - 1,
                round(y)
            )
        )

        global_x = monitor["left"] + x
        global_y = monitor["top"] + y

        button = message.get(
            "button",
            "left"
        )

        try:
            moved = win32_move_mouse(
                global_x,
                global_y
            )

            if not moved:
                return

            if message_type == "mouse_down":
                win32_mouse_button(
                    button,
                    True
                )

            elif message_type == "mouse_up":
                win32_mouse_button(
                    button,
                    False
                )

            elif message_type == "mouse_click":
                win32_click(button)

        except Exception as error:
            print(
                "Mouse input error:",
                error
            )

        return

    if message_type == "scroll":
        try:
            win32_scroll(
                int(
                    message.get(
                        "amount",
                        0
                    )
                )
            )
        except Exception:
            pass

        return

    if message_type == "text":
        text = message.get(
            "text",
            ""
        )

        if not isinstance(text, str):
            return

        try:
            win32_type_text(text)
        except Exception:
            pass

        return

    if message_type in (
        "key_down",
        "key_up"
    ):
        key = message.get(
            "key",
            ""
        )

        key = KEYS.get(
            key,
            key.lower()
            if key
            else key
        )

        if not key:
            return

        try:
            if message_type == "key_down":
                win32_key_down(key)
            else:
                win32_key_up(key)
        except Exception:
            pass


def receive_loop():
    global running

    while running:
        try:
            message = socket.recv()

            if not message:
                running = False
                break

            if isinstance(message, bytes):
                continue

            data = json.loads(message)

            message_type = data.get(
                "type",
                ""
            )

            if message_type == "viewer_count":
                count = int(
                    data.get(
                        "count",
                        0
                    )
                )

                was_streaming = is_streaming()
                now_streaming = count > 0

                set_streaming(now_streaming)

                if (
                    now_streaming and
                    not was_streaming
                ):
                    print(
                        " - User Connected."
                    )

                elif (
                    was_streaming and
                    not now_streaming
                ):
                    print(
                        " - User Disconnected."
                    )

                continue

            if message_type == "send_monitors":
                send_json({
                    "type": "monitors",
                    "monitors": get_monitors()
                })

                send_current_monitor()

                continue

            perform_input(data)

        except websocket.WebSocketTimeoutException:
            continue

        except Exception as error:
            print(
                "Receive error:",
                error
            )
            running = False
            break


def stream_loop():
    global running
    global last_sent_size

    frame_interval = 1.0 / FPS

    with mss.MSS() as sct:
        while running:
            if not is_streaming():
                time.sleep(0.05)
                continue

            started = time.perf_counter()

            try:
                with monitor_lock:
                    monitor_id = selected_monitor

                if (
                    monitor_id < 1 or
                    monitor_id >= len(sct.monitors)
                ):
                    monitor_id = 1

                monitor = sct.monitors[monitor_id]

                source_width = monitor["width"]
                source_height = monitor["height"]

                screenshot = sct.grab(monitor)

                image = Image.frombuffer(
                    "RGB",
                    screenshot.size,
                    screenshot.bgra,
                    "raw",
                    "BGRX",
                    0,
                    1,
                )

                if image.width > MAX_WIDTH:
                    scale = MAX_WIDTH / image.width

                    new_width = MAX_WIDTH
                    new_height = max(
                        1,
                        int(image.height * scale)
                    )

                    image = image.resize(
                        (new_width, new_height),
                        Image.Resampling.BILINEAR
                    )

                current_size = (
                    image.width,
                    image.height
                )

                set_stream_size(
                    image.width,
                    image.height
                )

                buffer = io.BytesIO()

                image.save(
                    buffer,
                    format="JPEG",
                    quality=JPEG_QUALITY,
                    optimize=False,
                    progressive=False,
                    subsampling=2
                )

                frame_data = buffer.getvalue()

                if not is_streaming():
                    continue

                if socket and socket.connected:
                    with socket_lock:
                        if current_size != last_sent_size:
                            last_sent_size = current_size

                            socket.send(
                                json.dumps({
                                    "type": "size",
                                    "width": image.width,
                                    "height": image.height,
                                    "source_width": source_width,
                                    "source_height": source_height,
                                    "monitor": monitor_id
                                })
                            )

                        socket.send(
                            frame_data,
                            opcode=websocket.ABNF.OPCODE_BINARY
                        )

            except Exception as error:
                print(
                    "Stream error:",
                    error
                )

            elapsed = (
                time.perf_counter() -
                started
            )

            delay = (
                frame_interval -
                elapsed
            )

            if delay > 0:
                time.sleep(delay)


def main():
    global socket
    global running
    global last_sent_size

    print("Nebula Connect")
    print()
    print()

    get_token()

    print()
    print(
        " - Connecting to the server..."
    )

    create_connection()

    websocket_url = (
        SERVER
        .replace(
            "https://",
            "wss://"
        )
        .replace(
            "http://",
            "ws://"
        )
        + "/connection/?="
        f"{encoded_token()}"
        "&role=agent"
    )

    try:
        socket = websocket.create_connection(
            websocket_url,
            timeout=None,
            http_proxy_host=None,
            http_proxy_port=None
        )

        socket.settimeout(None)

        try:
            socket.sock.setsockopt(
                socket_module.IPPROTO_TCP,
                socket_module.TCP_NODELAY,
                1
            )
        except Exception:
            pass

    except Exception as error:
        print(
            " - Could not connect:",
            error
        )

        raise SystemExit(1)

    print(
        " - Successful! Waiting for user connection..."
    )

    set_stream_size(0, 0)

    last_sent_size = None

    receiver = threading.Thread(
        target=receive_loop,
        daemon=True
    )

    receiver.start()

    try:
        stream_loop()

    except KeyboardInterrupt:
        pass

    finally:
        running = False

        try:
            socket.close()
        except Exception:
            pass

        print()
        print(
            " - Stopped."
        )


if __name__ == "__main__":
    main()